import Projects from "./Projects"

export const metadata = {
  title: "Projects | gilbertomorales.com",
}

export default function ProjectsPage() {
  return <Projects />
}
