import Home from "./Home"

export const metadata = {
  title: "Home | gilbertomorales.com",
}

export default function HomePage() {
  return <Home />
}
