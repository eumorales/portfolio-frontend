import Blog from "./Blog"

export const metadata = {
  title: "Blog | gilbertomorales.com",
}

export default function BlogPage() {
  return <Blog />
}
