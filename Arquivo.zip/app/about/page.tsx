import About from "./About";

export const metadata = {
  title: "About | gilbertomorales.com",
};

export default function AboutPage() {
  return <About />;
}
