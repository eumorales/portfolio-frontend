import Guestbook from "./Guestbook"

export const metadata = {
  title: "Guestbook | gilbertomorales.com",
}

export default function GuestbookPage() {
  return <Guestbook />
}
